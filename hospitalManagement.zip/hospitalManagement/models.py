from django.db import models
import sqlite3
# Create your models here.

class PatientFiles(models.Model):
    ID = models.IntegerField(max_length=100, null=True)
    Name = models.CharField(max_length=100, null=True)
    DOB = models.DateField()
    Address = models.CharField(max_length=100, null=True)
    email = models.CharField(max_length=100, null=True)
    phone = models.IntegerField(max_length=100, null=True)
    username = models.CharField(max_length=100, null=True)
    password = models.CharField(max_length=100, null=True)
    Ward = models.IntegerField(max_length=100, null=True)
    Doctor = models.IntegerField(max_length=100, null=True)
    Disease = models.CharField(max_length=100, null=True)
    Treatment = models.CharField(max_length=100, null=True)
    Investigation = models.CharField(max_length=100, null=True)
    Bloodtype = models.CharField(max_length=3, null=True)
    Time = models.IntegerField(max_length=100, null=True)
    Payment = models.IntegerField(max_length=100, null=True)
    Payment = 150 * Time

def Patientfilesdb(Patientfiles):
    query = "Insert into Patients (Patient_ID, Patient_Name, Patient_DOB, " \
            "Patient_Address,Patient_Email, Patient_Phone," \
    "Patient_Username, Patient_Password Patient_Ward, Patient_Doctor, " \
            "Patient_Disease, Patient_Treatment, Patient_Investigation, " \
    "Patient_Bloodtype,Patient_Duration, Patient_Cost) values('" + get_value(
        "ID") + "','" + get_value("Name") + "','" + get_value("Address")+"','"
    + get_value("email") +"','" + get_value("phone") +\
    "','" +get_value("username") + "','" + get_value("password")+ "','" +
    get_value("Ward")+"','" + get_value("Doctor")+
    "','" + get_value("Disease")+"','" + get_value("Treatment") +"','" + \
    get_value("Investigation") + "','" + get_value("Bloodtype")
    "','" + get_value("Time") + "','" + get_value("Payment") + "');"))
    return query

class DoctorFiles(models.Model):
    ID = models.IntegerField(max_length=100, null=True)
    Name = models.CharField(max_length=100, null=True)
    DOB = models.DateField()
    Address = models.CharField(max_length=100, null=True)
    email = models.CharField(max_length=100, null=True)
    phone = models.IntegerField(max_length=100, null=True)
    username = models.CharField(max_length=100, null=True)
    password = models.CharField(max_length=100, null=True)
    Ward = models.IntegerField(max_length=100, null=True)
    Speciality = models.IntegerField(max_length=100, null=True)
    Disease = models.CharField(max_length=100, null=True)
    Treatment = models.CharField(max_length=100, null=True)
    Investigation = models.CharField(max_length=100, null=True)
    

class ManagerFiles(models.Model):
    ID = models.IntegerField(max_length=100, null=True)
    Name = models.CharField(max_length=100, null=True)
    DOB = models.DateField()
    Address = models.CharField(max_length=100, null=True)
    email = models.CharField(max_length=100, null=True)
    phone = models.IntegerField(max_length=100, null=True)
    username = models.CharField(max_length=100, null=True)
    password = models.CharField(max_length=100, null=True)
    Position = models.CharField(max_length=100, null=True)
    Section = models.CharField(max_length=100, null=True)
    





fields = ['ID','Name', 'DOB', 'Address','email','phone','username', 
                  'password', 'Ward','Speciality','Disease','Treatment','Investigation']