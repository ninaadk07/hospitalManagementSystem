from django.shortcuts import render, redirect
from .decorators import unauthenticated_user, allowed_users
from .forms import CreateUserForm, ParticipantFilesModelForm,ZoomLinkModelForm, SubjectExpertFilesModelForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group, User, auth
from django.contrib import messages
from .models import ZoomLink, ParticipantFiles, SubjectExpertFiles
# Create your views here.


def HomePage(request):
    context = {}
    return render(request, 'welcomepage.html', context)

@unauthenticated_user
def PatientLoginPage(request):
    username = request.POST['username']
    password = request.POST['password']
    keyword = request.POST['keyword']

    user = auth.authenticate(username=username, password=password, keyword='beautiful')

    if user is not None:
            auth.login(request, user)
            messages.info(request, f'hello {username}')
            render(request, 'patienthomepage.html')

        else:
            messages.info(request, 'invalid credentials')

    context = {},
    return render(request, 'patientloginpage.html', context)

def DoctorLoginPage(request):
    if request.method== 'POST':
        username = request.POST['username']
        password = request.POST['password']
        keyword = request.POST['keyword']

        user = auth.authenticate(username=username, password=password, keyword='beautiful')

        if user is not None:
            auth.login(request, user)
            messages.info(request, f'hello {username}')

        else:
            messages.info(request, 'invalid credentials')

    context = {}
    return render(request, 'doctorloginpage.html', context)

def ManagerLoginPage(request):
    if request.method== 'POST':
        username=request.POST['username']
        password = request.POST['password']
        keyword = request.POST['keyword']

        user = auth.authenticate(username=username, password=password, keyword='beautiful')

        if user is not None:
            auth.login(request, user)
            messages.info(request, f'hello {username}')

        else:
            messages.info(request, 'invalid credentials')

    context = {}
    return render(request, 'managerloginpage.html', context)

@login_required(login_url='login')
def LogoutPage(request):
    auth.logout(request)
    return redirect('/')
    return render(request, 'logout.html')

@login_required(login_url='login')
@allowed_users(allowed_roles=['Patient', 'Manager'])
def DiseaseInformationPage(request):
    username = request.user.username
    print(username)
    return render(request, 'diseaseinfo.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['Patient'])
def AdmissionDetailsPage(request):
    username = request.user.username
    patient[0] = PatientFiles.objects.get(ID=ID)
    patient[1] = PatientFiles.objects.get(Name=name)
    patient[2] = PatientFiles.objects.get(Ward=ward)
    patient[3] = PatientFiles.objects.get(Doctor=doctor)
    patient[4] = PatientFiles.objects.get(Disease=disease)
    patient[5] = PatientFiles.objects.get(Treatment=treatment)
    patient[6] = PatientFiles.objects.get(Investigation=investigation)
    patient[7] = PatientFiles.objects.get(Bloodtype=bloodtype)
    patient[8] = PatientFiles.objects.get(Duration=duration)
    patient[9] = PatientFiles.objects.get(Payment=payment)
    context = {'patient':patient[1]}
    insert_into_patient_table(patient)
    return render(request, 'admissiondetails.html', context)

def insert_into_patient_table(patient):
    for x in range(9):
        patient[x] = table[x+1][1]


@login_required(login_url='login')
@allowed_users(allowed_roles=['Patient'])
def DoctorSearchPage(request):
    username = request.user.username
    n=0
    doctor[0] = DoctorFiles.objects.get(ID)
    doctor[1] = DoctorFiles.objects.get(Name)
    doctor[2] = DoctorFiles.objects.get(Ward)
    doctor[3] = DoctorFiles.objects.get(Speciality)
    n = n+1
    insert_into_doctor_table(doctor,n)
    return render(request, 'doctorsearch.html')

def insert_into_doctor_table(doctor,n):
    for x in range(n-1):
        for y in range(3):
            doctor[y] = table[x][y]



@login_required(login_url='login')
@allowed_users(allowed_roles=['Doctors'])
def Distreatreportpage(request):
    username = request.user.username
    doctor = DoctorFiles.objects.get(username=username)
    insert_into_reportpage(doctor)
    context = {'Doctor':doctor}
    return render(request, 'distreatreport.html', context)

def insert_into_reportpage(doctor, request):
    reportinfo[0] = request.user.name
    reportinfo[1] = request.user.disease
    reportinfo[2] = request.user.treatment
    return reportinfo

@login_required(login_url='login')
@allowed_users(allowed_roles=['Doctors'])
def Wardinfopage(request):
    username = request.user.username
    doctor = DoctorFiles.objects.get(username=username)
    insert_into_wardpage(doctor)
    context = {'Doctor':doctor}
    return render(request, 'wardinfo.html', context)

def insert_into_wardpage(doctor, request):
    reportinfo[0] = request.user.name
    reportinfo[1] = request.user.ward
    reportinfo[2] = request.user.disease
    return reportinfo

@login_required(login_url='login')
@allowed_users(allowed_roles=['Doctors'])
def Graphspage(request):
    return render(request, 'Graphs.html')

@login_required(login_url='login')
@allowed_users(allowed_roles=['Managers'])
def Graphsreportspage(request):
    return render(request, 'Graphsreports.html')

@login_required(login_url='login')
@allowed_users(allowed_roles=['Managers'])
def Hospitaldatapage(request):
    return render(request, 'Hospitaldata.html')

@login_required(login_url='login')
@allowed_users(allowed_roles=['Managers'])
def Coviddatapage(request):
    return render(request, 'Coviddata.html')

def RegisterPatientPage(request):
    form = CreatePatientUserForm()
    form2 = PatientFilesModelForm()
    if request.method == 'POST':
        failed = True
        form = CreatePatientUserForm(request.POST)
        form2 = PatientFilesModelForm(request.POST, request.FILES or None)
        print(form2)
        if form.is_valid():
            print('form1')
            user=form.save()
            group = Group.objects.get(name='Patient')
            user.groups.add(group)

            if form2.is_valid():
                print('form2')
                form2.save()
                form2 = PatientFilesModelForm()

                name = form.cleaned_data.get('Name')
                messages.success(request, 'Account was created for ' + name)
                failed=False
                form = CreatePatientUserForm()

        if failed == True:
            messages.error(request, 'please ensure all fields are filled correctly')
    context = {'form': form,
               'form2': form2}
    return render(request, 'Register_Patient.html', context)

)
def RegisterDoctorPage(request):
    form = CreateUserForm()
    form2 = SubjectExpertFilesModelForm
    if request.method == 'POST':
        failed = True
        form = CreateUserForm(request.POST)
        form2 = ParticipantFilesModelForm(request.POST, request.FILES or None)
        if form.is_valid():
            user=form.save()
            group = Group.objects.get(name='Doctor')
            user.groups.add(group)

            if form2.is_valid():
                form2.save()
                form2 = ParticipantFilesModelForm()

                firstname = form.cleaned_data.get('first_name')
                messages.success(request, 'Account was created for ' + firstname)
                failed=False
                form = CreateUserForm()

        if failed == True:
            messages.error(request, 'please ensure all fields are filled correctly')
    context = {'form': form,
               'form2': form2}
    return render(request, 'Register_Doctor.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['CoreCommittee'])
def RegisterManagerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        failed = True
        form = CreateUserForm(request.POST)

        if form.is_valid():
            user = form.save()
            group = Group.objects.get(name='Manager')
            user.groups.add(group)


            firstname = form.cleaned_data.get('first_name')
            messages.success(request, 'Account was created for ' + firstname)
            failed = False
            form = CreateUserForm()

        if failed==True:
            messages.error(request, 'please ensure all fields are filled correctly')
    context = {'form': form}
    return render(request, 'Register_Manager.html', context)

