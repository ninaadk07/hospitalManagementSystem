from django.contrib import admin
from.models import PatientFiles,DoctorFiles,ManagerFiles
# Register your models here.
admin.site.register(PatientFiles)
admin.site.register(DoctorFiles)
admin.site.register(ManagerFiles)