import sys
import sqlite3
from datetime import datetime
from dearpygui.core import *
from dearpygui.simple import *

print("hello")


def close(sender, data):
    delete_item("Patient Interface")


def exit_main_window(sender, data):
    stop_dearpygui
    sys.exit()


# get selected data from cell
def tablePrinter(sender, data):
    coordList = get_table_selections("Table Patient")
    row = 0
    for coordinates in coordList:
        row = coordinates[0]

    with window("Patient Interface"):
        set_value("Patient ID", get_table_item("Table Patient", row, 0))
        set_value("Patient Name", get_table_item("Table Patient", row, 1))
        set_value("Patient Dateofbirth", get_table_item("Table Patient", row, 2))
        set_value("Patient Address", get_table_item("Table Patient", row, 3))
        set_value("Patient Username", get_table_item("Table Patient", row, 4))
        set_value("Patient Password", get_table_item("Table Patient", row, 5))
        set_value("Patient Ward", get_table_item("Table Patient", row, 6))
        set_value("Patient Doctor", get_table_item("Table Patient", row, 7))
        set_value("Patient Disease", get_table_item("Table Patient", row, 8))
        set_value("Patient Treatment", get_table_item("Table Patient", row, 9))
        set_value("Patient Investigation", get_table_item("Table Patient", row, 10))
        set_value("Patient Bloodtype", get_table_item("Table Patient", row, 11))
        set_value("Patient Duration", get_table_item("Table Patient", row, 12))
        set_value("Patient Payment", get_table_item("Table Patient", row, 13))
        





def clear_patient_interface(sender, data):
    with window("Patient Interface"):
        set_value("Patient ID", "")
        set_value("Patient Name", "")
        set_value("Patient Dateofbirth", "")
        set_value("Patient Address", "")
        set_value("Patient Username", "")
        set_value("Patient Password", "")
        set_value("Patient Ward", "")
        set_value("Patient Doctor", "")
        set_value("Patient Disease", "")
        set_value("Patient Treatment", "")
        set_value("Patient Investigation", "")
        set_value("Patient Bloodtype", "")
        set_value("Patient Duration", "")
        set_value("Patient Payment", "")
        items = sup_display_data("select * from Patients;")
        for item in items:
            add_row("Table Patient", [item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13]])


# Display data from sqllite to the dearpygui table
def patient_display_data(str_select):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    c.execute(str_select)
    items = c.fetchall()
    return items
    conn.commit()
    conn.close()


# insert data in the table
def patient_add_data(str_insert):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    c.execute(str_insert)
    conn.commit()

    # clear contents of the supervisor form
    with window("Patient Interface"):
        set_value("Patient ID", "")
        set_value("Patient Name", "")
        set_value("Patient Dateofbirth", "")
        set_value("Patient Address", "")
        set_value("Patient Username", "")
        set_value("Patient Password", "")
        set_value("Patient Ward", "")
        set_value("Patient Doctor", "")
        set_value("Patient Disease", "")
        set_value("Patient Treatment", "")
        set_value("Patient Investigation", "")
        set_value("Patient Bloodtype", "")
        set_value("Patient Duration", "")
        set_value("Patient Payment", "")
        items = sup_display_data("select * from Patients;")
        for item in items:
            add_row("Table Patient", [item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13]])
    conn.close()

    # insert data in the table


def patient_edit_data(str_update):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    c.execute(str_update)
    conn.commit()
    # clear contents of the supervisor form
    with window("Patient Interface"):
        set_value("Patient ID", "")
        set_value("Patient Name", "")
        set_value("Patient Dateofbirth", "")
        set_value("Patient Address", "")
        set_value("Patient Username", "")
        set_value("Patient Password", "")
        set_value("Patient Ward", "")
        set_value("Patient Doctor", "")
        set_value("Patient Disease", "")
        set_value("Patient Treatment", "")
        set_value("Patient Investigation", "")
        set_value("Patient Bloodtype", "")
        set_value("Patient Duration", "")
        set_value("Patient Payment", "")
        items = sup_display_data("select * from Patients;")
        for item in items:
            add_row("Table Patient", [item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13]])
    conn.close()


# Delete data in the table
def patient_del_data(str_delete):
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute(str_delete)
    conn.commit()
    # clear contents of the supervisor form
    with window("Patient Interface"):
        set_value("Patient ID", "")
        set_value("Patient Name", "")
        set_value("Patient Dateofbirth", "")
        set_value("Patient Address", "")
        set_value("Patient Username", "")
        set_value("Patient Password", "")
        set_value("Patient Ward", "")
        set_value("Patient Doctor", "")
        set_value("Patient Disease", "")
        set_value("Patient Treatment", "")
        set_value("Patient Investigation", "")
        set_value("Patient Bloodtype", "")
        set_value("Patient Duration", "")
        set_value("Patient Payment", "")
        items = sup_display_data("select * from Patients;")
        for item in items:
            add_row("Table Patient", [item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13]])
    conn.close()


# window object settings
set_main_window_size(1366, 768)
set_main_window_pos(0, 0)
set_global_font_scale(1)
set_theme("Dark  ")
set_style_window_padding(30, 30)


def patient_Interface():
    with window("Patient Interface", width=1000, height=575, no_resize=True, no_move=False, no_close=True):
        add_text("This Section is to Add/Edit/Delete Patients", color=[232, 163, 33])
        add_separator()
        set_window_pos("Patient Interface", 200, 60)
        add_input_text("Patient ID", width=1)
        # Hide ID field
        hide_item("Patient ID")
        add_spacing(count=5)
        add_input_text("Patient Name", width=415)
        add_spacing(count=5)
        # suptype = ["Teacher", "Admin", "Assistant", "Club"]
        # add_combo("Supervisor Type", items=suptype, default_value="Teacher", width=415)
        # add_spacing(count=5)
        add_input_text("Patient Date of Birth", width=415)
        add_spacing(count=5)
        add_input_text("Patient Address", width=415)
        add_spacing(count=5)
        add_input_text("Patient Email", width=415)
        add_spacing(count=5)
        add_input_text("Patient Phone number", width=415)
        add_spacing(count=5)
        add_input_text("Patient Username", width=415)
        add_spacing(count=5)
        add_input_text("Patient Password", width=415)
        add_spacing(count=5)
        wardtype = ["1", "2", "3"]
        add_combo("Patient Ward", items = wardtype, default_value = "1", width=415)
        add_spacing(count=5)
        Doctors = ["Samantha", "Andrew"]
        add_combo("Patient Doctor", items = Doctors, default_value = "Samantha", width=415)
        add_spacing(count=5)
        diseases = ["Leukemia", "Influenza", "COVID 19"]
        add_combo("Patient_Disease", items = diseases, default_value = "Leukemia", width=415)
        add_spacing(count=5)
        add_input_text("Patient Investigation", width=415)
        add_spacing(count=5)
        add_input_text("Patient Bloodtype", width=415)
        add_spacing(count=5)
        add_input_text("Patient Time", width=415)
        add_spacing(count=5)
        add_input_text("Patient Payment", width=415)
        add_spacing(count=5)
        add_button("Add", callback=lambda: sup_add_data(
            "Insert into Patients(Patient_ID, Patient_Name, Patient_DOB, Patient_Address, Patient_Email, Patient_Phone, Patient_Username, Patient_Password, Patient_Ward, Patient_Doctor, Patient_Disease, Patient_Investigation, Patient_Bloodtype, Patient_Time, Patient_Payment) values('" + get_value(
                "Patient ID") + "','" + get_value("Patient Name") + "','" + get_value(
                "Patient Date of Birth") + get_value("Patient Address") + "','" + get_value(
                "Patient Email") + get_value("Patient Phone number") + "','" + get_value(
                "Patient Username") + get_value("Patient Password") + "','" + get_value(
                "Patient Ward") + get_value("Patient Doctor") + "','" + get_value(
                "Patient Disease") + get_value("Patient Investigation") + "','" + get_value(
                "Patient Bloodtype") + get_value("Patient Time") + "','" + get_value(
                "Patient Payment") + "');"))
        with popup("Add", "Add Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data added succesfully!", wrap=-1)
            add_button("Add Done", callback=lambda: close_popup("Add Message"))
        add_same_line()
        add_button("Edit", callback=lambda: sup_edit_data(
            "update supervisor SET Patient_Email = '" + get_value(
                "Patient Email") + "', Patient_Name = '" + get_value(
                "Patient_Name") + "', Patient_DOB ='" + get_value(
                "Patient Date of Birth") + "', Patient_Address = '" + get_value("Patient Address") + "' Patient_Phone = '" + get_value("Patient Phone number") + "' Patient_Username = '" + get_value(
                "Patient Username") + "'Patient_Password = '" + get_value("Patient Password") + "'Patient_Ward = '" + get_value(
                "Patient Ward") +"'Patient_Doctor = '" + get_value("Patient Doctor") + "'Patient_Disease ='" + get_value(
                "Patient Disease") + "'Patient_Investigation ='" + get_value("Patient Investigation") + "'Patient_Bloodtype ='" + get_value(
                "Patient Bloodtype") + "'Patient_Time ='" + get_value("Patient Time") + "'Patient_Payment ='"  + get_value(
                "Patient Payment") + "'where Patient_ID =" + get_value(
                "Patient ID") + ";"))
        with popup("Edit", "Update Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data deleted succesfully!", wrap=-1)
            add_button("Update Done", callback=lambda: close_popup("Update Message"))
        add_same_line()
        add_button("Delete",
                   callback=lambda: sup_del_data("Delete from Patients where Patient_ID = " + get_value("Patient ID")))
        with popup("Delete", "Delete Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data deleted succesfully!", wrap=-1)
            add_button("Delete Done", callback=lambda: close_popup("Delete Message"))
        add_same_line()
        add_button("Clear", callback=clear_sup_interface)
        with popup("Clear", "Clear Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Form cleared!", wrap=-1)
            add_button("Ok", callback=lambda: close_popup("Clear Message"))
        add_same_line()
        add_button("Close", callback=close)
        add_spacing(count=5)
        add_table("Table Supervisor", ["ID", "Name", "DOB", "Address", "Email", "Phone number", "Username", "Password", "Ward", "Doctor", "Disease", "Treatment", "Investigation", "Blood type", "Time","Payment"], callback=tablePrinter)
        items = sup_display_data("select * from Patients")
        for item in items:
            add_row("Table Patients", [item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13]])




def vol_close(sender, data):
    delete_item("Volunteer Interface")


# get selected data from cell
def vol_tablePrinter(sender, data):
    coordList = get_table_selections("Table Volunteer")
    row = 0
    for coordinates in coordList:
        row = coordinates[0]

    with window("Volunteer Interface"):
        set_value("Volunteer ID", get_table_item("Table Volunteer", row, 0))
        set_value("Volunteer Name", get_table_item("Table Volunteer", row, 1))
        set_value("Volunteer Year", get_table_item("Table Volunteer", row, 2))
        set_value("Volunteer Email", get_table_item("Table Volunteer", row, 3))


def clear_vol_interface(sender, data):
    with window("Volunteer ID"):
        set_value("Volunteer Name", "")
        set_value("Volunteer Year", "Teacher")
        set_value("Volunteer Email", "")
        clear_table("Table Volunteer")
        items = sup_display_data("select * from volunteers;")
        for item in items:
            add_row("Table Volunteer", [item[0], item[1], item[2], item[3]])


# Display data from sqllite to the dearpygui table
def vol_display_data(str_select):
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute(str_select)
    items = c.fetchall()
    return items
    conn.commit()
    conn.close()


# insert data in the table
def vol_add_data(str_insert):
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute(str_insert)
    conn.commit()
    print("this has added")
    # clear contents of the supervisor form
    with window("Volunteer Interface"):
        set_value("Volunteer Name", "")
        set_value("Volunteer Year", "10")
        set_value("Volunteer Email", "")
        clear_table("Table Volunteer")
        items = sup_display_data("select * from volunteers;")
        for item in items:
            add_row("Table Volunteer", [item[0], item[1], item[2], item[3]])
    conn.close()

    # insert data in the table


def vol_edit_data(str_update):
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute(str_update)
    conn.commit()
    # clear contents of the supervisor form
    with window("Volunteer Interface"):
        set_value("Volunteer Name", "")
        set_value("Volunteer Year", "10")
        set_value("Volunteer Email", "")
        clear_table("Table Volunteer")
        items = sup_display_data("select * from volunteers;")
        for item in items:
            add_row("Table Volunteer", [item[0], item[1], item[2], item[3]])
    conn.close()


# Delete data in the table
def vol_del_data(str_delete):
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute(str_delete)
    conn.commit()
    # clear contents of the supervisor form
    with window("Volunteer Interface"):
        set_value("Volunteer Name", "")
        set_value("Volunteer Year", "10")
        set_value("Volunteer Email", "")
        clear_table("Table Volunteer")
        items = sup_display_data("select * from volunteers;")
        for item in items:
            add_row("Table Volunteer", [item[0], item[1], item[2], item[3]])
    conn.close()


# window object settings
set_main_window_size(1366, 768)
set_main_window_pos(0, 0)
set_global_font_scale(1)
set_theme("Dark  ")
set_style_window_padding(30, 30)


def id_val():
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    b = c.fetchall()
    query = "SELECT * FROM volunteers"
    t = c.execute(query)
    b = []
    for l in t:
        b.append(l)
    k = len(b) + 1
    return str(k)


def vol_Interface():
    with window("Volunteer Interface", width=1000, height=575, no_resize=True, no_move=False, no_close=True):
        add_drawing("suplogo", width=48, height=48)  # create some space for the image
        draw_image("suplogo", "D:\Python Projects\supicon.png", [0, 0], [48, 48])
        add_text("This Section is to Add/Edit/Delete Volunteers", color=[232, 163, 33])
        add_separator()
        set_window_pos("Volunteer Interface", 200, 60)
        add_input_text("Volunteer ID", width=10)
        # Hide ID field
        # hide_item("Volunteer ID")
        add_spacing(count=5)
        add_input_text("Volunteer Name", width=415)
        add_spacing(count=5)
        years = ["10", "11", "12", "13"]
        add_combo("Volunteer Year", items=years, default_value="10", width=415)
        add_spacing(count=5)
        add_input_text("Volunteer Email", width=415)
        add_spacing(count=5)

        add_button("Add", callback=lambda: vol_add_data(
            "Insert into volunteers (vid, vname ,vyear, vemail) values('" + id_val() + "','" + get_value(
                "Volunteer Name") + "','" + get_value("Volunteer Year") + "','" + get_value("Volunteer Email") + "');"))
        with popup("Add", "Add Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data added succesfully!", wrap=-1)
            add_button("Add Done", callback=lambda: close_popup("Add Message"))
        add_same_line()
        add_button("Edit", callback=lambda: vol_edit_data(
            "update volunteers SET vname= '" + get_value("Volunteer Name") + "', vyear= '" + get_value(
                "Volunteer Year") + "', vemail='" + get_value("Volunteer Email") + "' where vid=" + get_value(
                "Volunteer ID") + ";"))
        with popup("Edit", "Update Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data deleted succesfully!", wrap=-1)
            add_button("Update Done", callback=lambda: close_popup("Update Message"))
        add_same_line()
        add_button("Delete",
                   callback=lambda: vol_del_data("Delete from volunteers where vid = " + get_value("Volunteer ID")))
        with popup("Delete", "Delete Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Data deleted succesfully!", wrap=-1)
            add_button("Delete Done", callback=lambda: close_popup("Delete Message"))
        add_same_line()
        add_button("Clear", callback=clear_vol_interface)
        with popup("Clear", "Clear Message", modal=True, mousebutton=mvMouseButton_Left):
            add_text("Form cleared!", wrap=-1)
            add_button("Ok", callback=lambda: close_popup("Clear Message"))
        add_same_line()
        add_button("Close", callback=vol_close)
        add_spacing(count=5)
        add_table("Table Volunteer", ["ID", "Name", "Year", "Email"], callback=vol_tablePrinter)
        items = vol_display_data("select * from volunteers;")
        for item in items:
            add_row("Table Volunteer", [item[0], item[1], item[2], item[3]])


# Main DiaTech Interface (Start Screen)
with window("Diatech Interface", width=1340, height=680, no_resize=False, no_move=False, no_close=True):
    set_window_pos("Diatech Interface", 0, 0)
    conn = sqlite3.connect('diatech.db')
    c = conn.cursor()
    c.execute("select * from supervisor;")
    conn.commit()
    now = datetime.now()
    dt_string = now.strftime("%d %B %Y %H:%M:%S")
    add_text("Welcome! You are sucessfully connected to Di@Tech Database ~ " + str(dt_string), color=[143, 216, 218])
    conn.close()
    # image logo
    add_drawing("logo", width=1300, height=550)  # create some space for the image
    draw_image("logo", "D:\Python Projects\diatech.jpg", [0, 0], [1300, 550])

    with menu_bar("Main Menu Bar"):
        with menu("File"):
            add_menu_item("Exit", callback=exit_main_window)

        with menu("Data Entry"):  # simple
            add_menu_item("Supervisor", callback=sup_Interface)
            add_menu_item("Volunteer", callback=vol_Interface)
            add_menu_item("Activity")
        with menu("Reports"):  # simple
            add_menu_item("Supervisor Report")
            add_menu_item("Volunteer Report")
            add_menu_item("Activity Report")

start_dearpygui()