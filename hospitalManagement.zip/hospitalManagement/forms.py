from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User
from.models import PatientFiles,DoctorFiles,ManagerFiles

class CreatePatientUserForm(UserCreationForm):
    class Meta:
        model=User
        fields = ['ID','Name', 'DOB', 'Address','email',
                  'phone','username', 'password', 'Ward','Doctor','Disease','Treatment',
                  'Investigation','Bloodtype','Time','Payment']

class CreateDoctorUserForm(UserCreationForm):
    class Meta:
        model=User
        fields = ['ID','Name', 'DOB', 'Address','email','phone','username', 'password', 
                  'Ward','Speciality','Disease','Treatment','Investigation']

class CreateManagerUserForm(UserCreationForm):
    class Meta:
        model=User
        fields = ['ID','Name', 'DOB', 'Address','email','phone',
                  'username', 'password', 'Position', 'Section']

class PatientFilesModelForm(forms.ModelForm):
    class Meta:
        model = PatientFiles
        fields = ['ID','Name', 'DOB', 'Address','email','phone','username', 
                  'password', 'Ward','Doctor','Disease',
                  'Treatment','Investigation','Bloodtype','Time','Payment']

class DoctorFilesModelForm(forms.ModelForm):
    class Meta:
        model = DoctorFiles
        fields = ['ID','Name', 'DOB', 'Address','email','phone','username', 
                  'password', 'Ward','Speciality','Disease','Treatment','Investigation']
        
class ManagerFilesModelForm(forms.ModelForm):
    class Meta:
        model = ManagerFiles
        fields = ['ID', 'Name', 'DOB', 'Address', 'email', 'phone',
                  'username', 'password', 'Position', 'Section']

