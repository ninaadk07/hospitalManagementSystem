
import sqlite3

def diseaseinfoadd(request):
        conn = sqlite3.connect('hospital.db')
        c = conn.cursor()
        query1 = "select Disease_ID, Disease_Name from Diseases"
        query2 = table.append(query1)
        query3 = " select Disease_Information from Diseases"
        return query2, query3

def admissiondetails(request):
        conn = sqlite3.connect('hospital.db')
        c = conn.cursor()
        username = request.user.username
        query = "select Patient_ID, Patient_Name, Patient_Ward, Patient_Doctor, Patient_Disease, Patient_Treatment, Patient_Investigation, Patient_Bloodtype,Patient_Duration, Patient_Cost from Patients where Patient_Username = 'username'"
        id_val("Patient_Doctor")
        return query

def id_val(a):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    b = c.fetchall()
    query = "SELECT * FROM Doctors"
    t = c.execute(query)
    b = []
    for l in t:
        b.append(l)
        if "Doctor_Name"= a:
            break
    k = len(b) + 1
    return str(k)

def searchdoctor():
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    query = " select Doctor_ID, Doctor_Name, Doctor_Ward, Doctor_Speciality from Doctors"
    return query

def wardinfo():
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    query = " select Patient_ID, Patient_Name, Patient_Patient_Time from Patients " \
            "inner join Doctors on Patients.Patient_Doctor = Doctors.Doctor_Name where Doctor_Ward = '1'"
    return query

import pandas as pd

def wardreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Doctor_Ward from Doctor where Doctor_Name = '%s'" %(username)
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient ID, Patient_Name from Patients where Patient_Ward = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k}
    df = pd.DataFrame(data, columns  = ['ID', 'Name'])
    return df.to_excel('./report1.xlsx')

def wardreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Doctor_Ward from Doctor where Doctor_Name = '%s'" %(username)
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient_ID, Patient_Name from Patients where Patient_Ward = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k}
    df = pd.DataFrame(data, columns  = ['ID', 'Name'])
    return df.to_excel('./report1.xlsx')

def bloodtestreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Patient_ID from Patients"
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient_Name, Patient_Bloodtype from Patients where Patient_ID = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'Name':z,
        'Bloodtype':k}
    df = pd.DataFrame(data, columns  = ['Name', 'Bloodtype'])
    return df.to_excel('./report2.xlsx')

def diagnosisreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Doctor_Disease from Doctor where Doctor_Name = '%s'" %(username)
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient_ID, Patient_Name from Patients where Patient_Disease = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k}
    df = pd.DataFrame(data, columns  = ['ID', 'Name'])
    return df.to_excel('./report3.xlsx')

def admissionsreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Patient_ID from Patients where Patient_Time = '0'"
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient_Name, Patient_Disease from Patients where Patient-ID = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k}
    df = pd.DataFrame(data, columns  = ['Name', 'Disease'])
    return df.to_excel('./report4.xlsx')

def Treatmentreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Doctor_Treatment from Doctor where Doctor_Username = '%s'" %(username)
    h = c.execute(query)
    k = []
    z = []
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Patient_Name, Patient_ID from Patients where Patient_Treatment = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k}
    df = pd.DataFrame(data, columns  = ['Name', 'ID'])
    return df.to_excel('./report5.xlsx')

def Doctorreportexcel(request):
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    username = request.user.username
    query = "select Doctor_Speciality from Doctors"
    h = c.execute(query)
    k = []
    z = []
    r=[]
    for g in h:
        ui = str(g)
        k.append(ui[2:-3])
    for i in k:
        query1 = "select Doctor_Name, Doctor_ID, Doctor_Speciality from Doctors where Doctor_Speciality = '%s'" %(i)
        p = c.execute(query1)
        for g in p:
            z.append(g)
    data = {'ID':z,
        'Name':k,
            'Speciality':r}
    df = pd.DataFrame(data, columns  = ['Name', 'ID','Speciality'])
    return df.to_excel('./report6.xlsx')

import matplotlib.pyplot as plt
def graphtotaladmissions():
    y = [0, 1, 2, 2]
    x = [0, 5, 40, 45]
    plt.plot(x, y)
    plt.xlabel('time')
    plt.ylabel('total admissions')
    plt.title('Total admissions vs time')
    plt.show()

def graphpayment():
    left = [1, 2]
    height = [7600,750]
    tick_label = ['James Johnson','Harry Smith']
    plt.bar(left, height, tick_label=tick_label,
            width=0.8, color=['red', 'green'])
    plt.xlabel('Patient names')
    plt.ylabel('Payment')
    plt.title('Payment Progress')
    plt.show()

def graphward():
    Wards = ['Ward 1', 'Ward 2']
    slices = [21,15]
    colors = ['r', 'g']
    plt.pie(slices, labels=Wards, colors=colors,
            startangle=90, shadow=True, explode=(0, 0, 0.1, 0),
            radius=1.2, autopct='%1.1f%%')
    plt.legend()
    plt.show()

def hospitaldata():
    query1 = "Select Patient_ID, Patient_Name, Patient_Time from Patients"
    query2 = "Select Doctor_ID, Doctor_Name, Doctor_Speciality from Doctors"
    query3 = "Select Manager_ID, Manager_Name, Manager_Position from Managers"
    query4 = "Select Ward_Number, Ward_Disease, Ward_Capacity from Wards"
    return query1,query2,query3,query4

def coviddata():
    patientcvd = 0, doctorcvd = 0
    query1 = "Select Patient_ID, Patient_Name from Patients where Patient_Disease = 'COVID-19'"
    patientcvd = patientcvd +1
    query2 = "Select Doctor_ID, Doctor_Name from Doctors where Doctor_Disease = COVID-19"
    doctorcvd = doctorcvd+1
    return patientcvd, doctorcvd,query1,query2

import smtplib, ssl
def emailsend():
    query1 = "Select Patient_Doctor from Patients where Patient_Name = Name"
    query2 = "Select Doctor_Name from Doctors where Doctor_ID = query1"
    query3 = "Select Doctor_Email from Doctors where Doctor_ID = query1"
    sender_email = "admnlh2022cs@gmail.com"
    receiver_email = query3
    message = """\
    Subject: New Ward Admission Reminder
    
    Dear """ + query2 + """\
    This is an automated email sent to inform you about a new admission to your ward
    Patient Name:""" + Name + """\
    Patient Date of Birth:""" + DOB + """\
    Patient Disease:""" + Disease +  """\
    Patient Treatment""" + Treatment + """\
    Patient Bloodtype""" + Bloodtype + """\
    
    From
    Latifa Hospital Records System
    """
    return server.sendmail(sender_email, receiver_email, message)

