def connectiontodb():
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    c.execute(str_insert)
    conn.commit()

def Patient_add_data():
        "Insert into Patients(Patient_ID, Patient_Name, Patient_DOB, Patient_Address, Patient_Email, Patient_Phone, Patient_Username, Patient_Password, Patient_Ward, Patient_Doctor, Patient_Disease, Patient_Investigation, Patient_Bloodtype, Patient_Time, Patient_Payment) values('" + PatientFiles.object.get()
        
